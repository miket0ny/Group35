function showThankYou() {
  alert("Thank you for contacting us!");
}
