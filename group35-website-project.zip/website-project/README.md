# Group 35 Website

This is a 5-page website built with HTML, CSS, and JavaScript.

## Pages
- Home
- About Us
- Services
- Gallery
- Contact

## Features
- Left-aligned logo
- Image grid in gallery
- Contact form with thank-you alert
- Footer on every page

## Group 35
